from django.contrib import admin
from .models import ContactMessage

admin.site.register(ContactMessage)


